<h1>Loyal and Loyal Sans Version 1.0</h1>

Loyal was engineered in 2021 to support display and body copy and published in late 2023 with 9 fonts. 
Version 1.1 will include expanded ligatures and italic fonts for serifs, at the very least.

Please refer to <a href="https://emmetblanchettedesign.com/loyal">emmetblanchettedesign.com/loyal</a> for the full case study.

<h4>Loyal is licensed under the SIL Open Font License v1.1.</h4>

![letter-parts-14](https://github.com/emmetblanchette/Loyal-Font-Family/assets/158105211/238b4973-1461-4b42-80f5-544aa2061180)
![letter-parts-12](https://github.com/emmetblanchette/Loyal-Font-Family/assets/158105211/2f7c89b1-8e0e-4b7f-a885-bb700c0656d4)
![letter-parts-13](https://github.com/emmetblanchette/Loyal-Font-Family/assets/158105211/b40496a1-313f-4a83-8f55-15d0a2af9f77)
